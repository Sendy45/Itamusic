package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    ImageButton btnInstrumentsActivity, btnExercisesActivity;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("HomeActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("HomeActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        btnInstrumentsActivity = findViewById(R.id.btnInstrumentsActivity);
        btnExercisesActivity = findViewById(R.id.btnExercisesActivity);

        btnInstrumentsActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveInstrument = new Intent(HomeActivity.this, InstrumentsMenuActivity.class);
                moveInstrument.putExtra("user", user);
                startActivity(moveInstrument);
            }
        });
        btnExercisesActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveExercise = new Intent(HomeActivity.this, ExercisesMenuActivity.class);
                moveExercise.putExtra("user", user);
                startActivity(moveExercise);
            }
        });
    }
}