package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class NoteTestActivity extends AppCompatActivity {

    Button btnNoteAns1, btnNoteAns2, btnNoteAns3, btnNoteAns4;
    TextView tvNoteScore;
    private Piano piano;
    private ArrayList<Button> buttonList;
    private ArrayList<String> noteNameList;
    private int counter = 0;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_test);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("NoteTestActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("NoteTestActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        btnNoteAns1 = findViewById(R.id.btnNoteAns1);
        btnNoteAns2 = findViewById(R.id.btnNoteAns2);
        btnNoteAns3 = findViewById(R.id.btnNoteAns3);
        btnNoteAns4 = findViewById(R.id.btnNoteAns4);
        tvNoteScore = findViewById(R.id.tvNoteScore);

        buttonList = new ArrayList<>(Arrays.asList(btnNoteAns1,btnNoteAns2,btnNoteAns3,btnNoteAns4));

        piano = new Piano(getApplicationContext());

        noteNameList = piano.getNotesNamesList();

        nextQuestion();



    }
    public void playNote(Note note, int millis)
    {
        //Create a handler
        Handler handler = new Handler();
        // Create a runnable that will be executed after the delay
        Runnable runnable = new Runnable() { @Override public void run() {
            // Code to execute after the delay
            note.play();
        } };
        // Post the runnable with a delay
        handler.postDelayed(runnable, millis);
    }
    public void nextQuestion()
    {
        Random r = new Random();
        ArrayList<Button> buttonAnswerList = new ArrayList<>();
        ArrayList<String> answerList = new ArrayList<>();
        Note note = piano.getNotesList().get(r.nextInt(11));
        answerList.add(note.getName());

        int ansBtnNum = r.nextInt(4);
        buttonAnswerList.add(buttonList.get(ansBtnNum));
        buttonAnswerList.get(0).setText(note.getName());
        for(int i = 0; i<4; i++)
        {
            if (i!=ansBtnNum)
            {
                String ansWrong = noteNameList.get(r.nextInt(11));
                while (answerList.contains(ansWrong))
                    ansWrong = noteNameList.get(r.nextInt(11));
                answerList.add(ansWrong);
                buttonAnswerList.add(buttonList.get(i));
                buttonList.get(i).setText(ansWrong);
            }
        }


        playNote(note,1000);
        checkAnswer(buttonAnswerList);
    }
    public void checkAnswer(ArrayList<Button> buttonAnswerList)
    {
        // Make sure the list is not empty and has at least 4 buttons
        if (buttonAnswerList.size() < 4) {
            throw new IllegalArgumentException("buttonAnswerList must contain at least 4 buttons.");
        }
        buttonAnswerList.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter++;
                tvNoteScore.setText(counter+"");
                FirebaseHelper firebaseHelper = new FirebaseHelper();
                Stats stats = user.getStats();
                stats.incrementNoteListeningQuestions(true);
                firebaseHelper.uploadUserStats(user.getId(), stats);
                nextQuestion();
            }
        });
        buttonAnswerList.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
        buttonAnswerList.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
        buttonAnswerList.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
    }
}