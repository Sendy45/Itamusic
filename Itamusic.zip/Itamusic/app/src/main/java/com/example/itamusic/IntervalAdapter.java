package com.example.itamusic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class IntervalAdapter extends ArrayAdapter<Interval>
{
    Context context;
    ArrayList<Interval> objects;
    public IntervalAdapter( Context context, int resource,
                      ArrayList<Interval> objects) {
        super(context, resource, objects);
        this.context=context;
        this.objects=objects;
    }
    public View getView(int position, @Nullable View convertView,
                        @NonNull ViewGroup parent) {

        View v = convertView;
        LayoutInflater inflater = (LayoutInflater)
                getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = inflater.inflate(R.layout.interval_adapter, null);
        TextView tvNote1= v.findViewById(R.id.tvNote1);
        TextView tvNote2= v.findViewById(R.id.tvNote2);
        TextView tvTones= v.findViewById(R.id.tvTones);
        tvNote1.setText(objects.get(position).getNote1().getName());
        tvNote2.setText(objects.get(position).getNote2().getName());
        tvTones.setText(""+objects.get(position).getHalf_tones());
        return v;
    }
}

