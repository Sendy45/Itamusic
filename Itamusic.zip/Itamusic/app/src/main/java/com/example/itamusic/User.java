package com.example.itamusic;

import java.io.Serializable;

public class User implements Serializable {
    private String name;
    private String id;
    private String user_name;
    private String password;
    private Stats stats;

    public User(String name, String id, String user_name, String password, Stats stats) {
        this.name = name;
        this.id = id;
        this.user_name = user_name;
        this.password = password;
        this.stats = stats;
    }

    // No-argument constructor required for Firebase deserialization
    public User() {
        // Empty constructor for Firebase
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Stats getStats() {
        return stats;
    }

    public void setStats(Stats stats) {
        this.stats = stats;
    }
}
