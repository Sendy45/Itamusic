package com.example.itamusic;

public class Interval {
    private Note note1;
    private Note note2;
    private int half_tones;

    public Interval(Note note1, Note note2) {
        this.note1 = note1;
        this.note2 = note2;
        half_tones = Math.abs(note1.getHalf_tones()- note2.getHalf_tones());
    }

    public Note getNote1() {
        return note1;
    }

    public void setNote1(Note note1) {
        this.note1 = note1;
    }

    public Note getNote2() {
        return note2;
    }

    public void setNote2(Note note2) {
        this.note2 = note2;
    }

    public int getHalf_tones() {
        return half_tones;
    }

    public void setHalf_tones(int half_tones) {
        this.half_tones = half_tones;
    }
    public void play() {
        note1.play();
        note2.play();
    }
}
