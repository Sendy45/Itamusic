package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class IntervalTestActivity extends AppCompatActivity {

    Button btnIntervalAns1, btnIntervalAns2, btnIntervalAns3, btnIntervalAns4;
    TextView tvIntervalScore;
    private Piano piano;
    private ArrayList<Button> buttonList;
    private int counter = 0;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interval_test);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("IntervalTestActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("IntervalTestActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        btnIntervalAns1 = findViewById(R.id.btnIntervalAns1);
        btnIntervalAns2 = findViewById(R.id.btnIntervalAns2);
        btnIntervalAns3 = findViewById(R.id.btnIntervalAns3);
        btnIntervalAns4 = findViewById(R.id.btnIntervalAns4);
        tvIntervalScore = findViewById(R.id.tvIntervalScore);

        buttonList = new ArrayList<>(Arrays.asList(btnIntervalAns1,btnIntervalAns2,btnIntervalAns3,btnIntervalAns4));

        piano = new Piano(getApplicationContext());
        nextQuestion();



    }
    public void playNote(Note note, int millis)
    {
        //Create a handler
        Handler handler = new Handler();
        // Create a runnable that will be executed after the delay
        Runnable runnable = new Runnable() { @Override public void run() {
            // Code to execute after the delay
            note.play();
        } };
        // Post the runnable with a delay
        handler.postDelayed(runnable, millis);
    }
    public void playNote(Note note1, Note note2, int millis)
    {
        //Create a handler
        Handler handler = new Handler();
        // Create a runnable that will be executed after the delay
        Runnable runnable = new Runnable() { @Override public void run() {
            // Code to execute after the delay
            note1.play();
            note2.play();
        } };
        // Post the runnable with a delay
        handler.postDelayed(runnable, millis);
    }
    public void nextQuestion()
    {
        Random r = new Random();
        ArrayList<Button> button_answer_list = new ArrayList<>();
        ArrayList<Integer> answer_list = new ArrayList<>();
        Note note1 = piano.getNotesList().get(r.nextInt(11));
        Note note2 = piano.getNotesList().get(r.nextInt(11));
        Interval interval = new Interval(note1, note2);
        answer_list.add(interval.getHalf_tones());

        int ansBtnNum = r.nextInt(4);
        button_answer_list.add(buttonList.get(ansBtnNum));
        button_answer_list.get(0).setText(interval.getHalf_tones()+"");
        for(int i = 0; i<4; i++)
        {
            if (i!=ansBtnNum)
            {
                int ansWrong = r.nextInt(11);
                while (answer_list.contains(ansWrong))
                    ansWrong = r.nextInt(11);
                answer_list.add(ansWrong);
                button_answer_list.add(buttonList.get(i));
                buttonList.get(i).setText(ansWrong+"");
            }
        }


        playNote(note1,note2,1000);
        checkAnswer(button_answer_list);
    }
    public void checkAnswer(ArrayList<Button> button_answer_list)
    {
        // Make sure the list is not empty and has at least 4 buttons
        if (button_answer_list.size() < 4) {
            throw new IllegalArgumentException("buttonAnswerList must contain at least 4 buttons.");
        }
        button_answer_list.get(0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter++;
                tvIntervalScore.setText(counter+"");
                FirebaseHelper firebaseHelper = new FirebaseHelper();
                Stats stats = user.getStats();
                stats.incrementIntervalListeningQuestions(true);
                firebaseHelper.uploadUserStats(user.getId(), stats);
                nextQuestion();
            }
        });
        button_answer_list.get(1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
        button_answer_list.get(2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
        button_answer_list.get(3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion();
            }
        });
    }

}