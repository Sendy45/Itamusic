package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class  MainActivity extends AppCompatActivity {

    Button btnSignUp, btnAddUser;
    ImageButton btnLogIn;
    EditText etName, etId, etUserName, etPassword, etUserNameLogIn, etPasswordLogIn;
    Dialog signUpDialog;
    private ArrayList<User> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogIn = findViewById(R.id.btnLogIn);
        btnSignUp = findViewById(R.id.btnSignUp);
        etUserNameLogIn = findViewById(R.id.etUserNameLogIn);
        etPasswordLogIn = findViewById(R.id.etPasswordLogIn);

        users = FirebaseHelper.getAllUsers(MainActivity.this);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createSignUpDialog();
            }
        });

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = etUserNameLogIn.getText().toString();
                String password = etPasswordLogIn.getText().toString();

                if ((userName.isEmpty()) || (password.isEmpty())) {
                    Toast.makeText(MainActivity.this, "Not all fields are filled", Toast.LENGTH_SHORT).show();
                } else if(!checkUserLogIn(userName,password)){
                    Toast.makeText(MainActivity.this, "User does not exists", Toast.LENGTH_SHORT).show();
                } else{
                    Intent moveHome = new Intent(MainActivity.this, HomeActivity.class);
                    // Put the object into the intent
                    User user = getIdByLogIn(userName, password);
                    moveHome.putExtra("user", user);
                    startActivity(moveHome);
                }

            }
        });

    }
    public void createSignUpDialog()
    {
        signUpDialog = new Dialog(MainActivity.this);
        signUpDialog.setContentView(R.layout.sign_up_dialog);
        etName = signUpDialog.findViewById(R.id.etName);
        etId = signUpDialog.findViewById(R.id.etId);
        etUserName = signUpDialog.findViewById(R.id.etUserName);
        etPassword = signUpDialog.findViewById(R.id.etPassword);
        btnAddUser = signUpDialog.findViewById(R.id.btnAddUser);
        signUpDialog.show();

        btnAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString();
                String userName = etUserName.getText().toString();
                String id = etId.getText().toString();
                String password = etPassword.getText().toString();

                if ((name.isEmpty()) || (userName.isEmpty()) || (password.isEmpty()) || (id.length()!=9)) {
                    Toast.makeText(MainActivity.this, "Not all fields are filled or correct", Toast.LENGTH_SHORT).show();
                } else if (checkUserSignUp(id, userName, password)) {
                    Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                }
                else {
                    User newUser = new User(name, id, userName, password, new Stats());
                    FirebaseHelper firebaseHelper = new FirebaseHelper();
                    firebaseHelper.uploadUserData(newUser);
                    users = FirebaseHelper.getAllUsers(getApplicationContext());
                }
            }
        });
    }
    public boolean checkUserLogIn(String userName, String password)
    {
        for(int i=0;i<users.size();i++)
        {
            if(users.get(i).getUser_name().equals(userName) &&
                    users.get(i).getPassword().equals(password))
                return true;
        }
        return false;
    }
    public boolean checkUserSignUp(String id, String userName, String password)
    {
        for(int i=0;i<users.size();i++)
        {
            if(users.get(i).getId().equals(id))
                return true;
            if(users.get(i).getUser_name().equals(userName) &&
                    users.get(i).getPassword().equals(password))
                return true;
        }
        return false;
    }
    public User getIdByLogIn(String userName, String password)
    {
        for(int i=0;i<users.size();i++)
        {
            if(users.get(i).getUser_name().equals(userName) &&
                    users.get(i).getPassword().equals(password))
                return users.get(i);
        }
        return null;
    }
}