package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class IntervalsActivity extends AppCompatActivity {

    ListView lvIntervals;
    ArrayList<Interval> intervals = new ArrayList<>();
    ArrayList<Interval> filtered_intervals;
    Piano piano;
    Dialog dialog_interval;
    TextView tvNote1Dialog, tvNote2Dialog, tvTonesDialog;
    EditText etFindIntervals;
    Button btnCloseDialog, btnFindIntervals;
    private Note cNote,dNote,eNote,fNote,gNote,aNote,bNote,csNote,dsNote,fsNote,gsNote,asNote,ccNote,ccsNote;

    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intervals);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("IntervalActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("IntervalActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        lvIntervals = findViewById(R.id.lvIntervals);
        etFindIntervals=findViewById(R.id.etFindIntervals);
        btnFindIntervals=findViewById(R.id.btnFindIntervals);
        piano = new Piano(getApplicationContext());

        cNote = piano.getC4Note();
        csNote = piano.getCs4Note();
        dNote = piano.getD4Note();
        dsNote = piano.getDs4Note();
        eNote = piano.getE4Note();
        fNote = piano.getF4Note();
        fsNote = piano.getFs4Note();
        gNote = piano.getG4Note();
        gsNote = piano.getGs4Note();
        aNote = piano.getA4Note();
        asNote = piano.getAs4Note();
        bNote = piano.getB4Note();
        ccNote = piano.getC5Note();
        ccsNote = piano.getCs5Note();

        intervals.add(new Interval(cNote,bNote));
        intervals.add(new Interval(aNote,bNote));
        intervals.add(new Interval(eNote,gsNote));
        intervals.add(new Interval(asNote,ccsNote));
        intervals.add(new Interval(dNote,bNote));
        intervals.add(new Interval(bNote,fNote));
        intervals.add(new Interval(dNote,aNote));

        refresh(intervals);

        lvIntervals.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                intervals.get(i).play();
                createDialog();
                Interval interval=intervals.get(i);
                tvNote1Dialog.setText(interval.getNote1().getName());
                tvNote2Dialog.setText(interval.getNote2().getName());
                tvTonesDialog.setText(""+interval.getHalf_tones());
                btnCloseDialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog_interval.dismiss();
                    }
                });
            }
        });

        btnFindIntervals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filtered_intervals = new ArrayList<>();
                int half_tones = Integer.parseInt(etFindIntervals.getText().toString());
                for(int i=0;i<intervals.size();i++)
                {
                    if (intervals.get(i).getHalf_tones()==half_tones)
                        filtered_intervals.add(intervals.get(i));
                }
                refresh(filtered_intervals);
            }
        });

    }
    public void refresh(ArrayList<Interval> intervals_list)
    {
        IntervalAdapter adapter = new IntervalAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,intervals_list);
        lvIntervals.setAdapter(adapter);
    }
    public void createDialog()
    {
        dialog_interval=new Dialog(IntervalsActivity.this);
        dialog_interval.setContentView(R.layout.dialog_interval);
        tvNote1Dialog=dialog_interval.findViewById(R.id.tvNote1Dialog);
        tvNote2Dialog=dialog_interval.findViewById(R.id.tvNote2Dialog);
        tvTonesDialog=dialog_interval.findViewById(R.id.tvTonesDialog);
        btnCloseDialog=dialog_interval.findViewById(R.id.btnCloseDialog);
        dialog_interval.show();


    }
}