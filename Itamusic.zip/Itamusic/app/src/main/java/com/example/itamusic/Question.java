package com.example.itamusic;

import java.util.ArrayList;

public class Question {
    private String questionText;  // The text of the question
    private ArrayList<String> answers; // List of possible answers
    private int correctAnswerIndex; // Index of the correct answer in the list

    // Constructor
    public Question(String questionText, ArrayList<String> answers, int correctAnswerIndex) {
        this.questionText = questionText;
        this.answers = answers;
        this.correctAnswerIndex = correctAnswerIndex;
    }

    // Getter for the question text
    public String getQuestionText() {
        return questionText;
    }

    // Getter for the possible answers
    public ArrayList<String> getAnswers() {
        return answers;
    }

    // Getter for the correct answer
    public String getCorrectAnswer() {
        return answers.get(correctAnswerIndex);
    }

    // Method to check if an answer is correct
    public boolean isCorrect(int answerIndex) {
        return answerIndex == correctAnswerIndex;
    }

    // Method to validate an answer index
    public boolean isValidAnswerIndex(int index) {
        return index >= 0 && index < answers.size();
    }
}

