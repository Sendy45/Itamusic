package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ExercisesMenuActivity extends AppCompatActivity {

    Button btnIntervalActivity, btnIntervalTestActivity, btnNoteTestActivity;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises_menu);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("ExercisesMenuActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("ExercisesMenuActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        btnIntervalActivity = findViewById(R.id.btnIntervalActivity);
        btnIntervalTestActivity = findViewById(R.id.btnIntervalTestActivity);
        btnNoteTestActivity = findViewById(R.id.btnNoteTestActivity);

        btnIntervalActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveInterval = new Intent(getApplicationContext(), IntervalsActivity.class);
                moveInterval.putExtra("user", user);
                startActivity(moveInterval);
            }
        });
        btnIntervalTestActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveIntervalTest = new Intent(getApplicationContext(), IntervalTestActivity.class);
                moveIntervalTest.putExtra("user", user);
                startActivity(moveIntervalTest);
            }
        });
        btnNoteTestActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveNoteTest = new Intent(getApplicationContext(), NoteTestActivity.class);
                moveNoteTest.putExtra("user", user);
                startActivity(moveNoteTest);
            }
        });
    }
}