package com.example.itamusic;

import android.content.Context;

import java.util.ArrayList;
import java.util.Arrays;

public class Piano extends Instrument{
    private String name;
    private ArrayList<Note> notesList;
    private ArrayList<String> notesNamesList;
    private Note cNote,dNote,eNote,fNote,gNote,aNote,bNote,csNote,dsNote,fsNote,gsNote,asNote,ccNote,ddNote,eeNote,ffNote,ggNote,ccsNote,ddsNote,ffsNote;


    public Piano(Context context){
        name = "piano";
        cNote = new Note("c4",R.raw.c4,context,0);
        csNote = new Note("c_b4",R.raw.c_b4,context,1);
        dNote = new Note("d4",R.raw.d4,context,2);
        dsNote = new Note("d_b4",R.raw.d_b4,context,3);
        eNote = new Note("e4",R.raw.e4,context,4);
        fNote = new Note("f4",R.raw.f4,context,5);
        fsNote = new Note("f_b4",R.raw.f_b4,context,6);
        gNote = new Note("g4",R.raw.g4,context,7);
        gsNote = new Note("g_b4",R.raw.g_b4,context,8);
        aNote = new Note("a4",R.raw.a4,context,9);
        asNote = new Note("a_b4",R.raw.a_b4,context,10);
        bNote = new Note("b4",R.raw.b4,context,11);
        ccNote = new Note("c5",R.raw.c5,context,12);
        ccsNote = new Note("c_b5",R.raw.c_b5,context,13);
        ddNote = new Note("d5",R.raw.d5,context,14);
        ddsNote = new Note("d_b5",R.raw.d_b5,context,15);
        eeNote = new Note("e5",R.raw.e5,context,16);
        ffNote = new Note("f5",R.raw.f5,context,17);
        ffsNote = new Note("f_b5",R.raw.f_b5,context,18);
        ggNote = new Note("g5",R.raw.g5,context,19);
        notesList = new ArrayList<>(Arrays.asList(cNote,dNote,eNote,fNote,gNote,aNote,bNote,csNote,dsNote,fsNote,gsNote,asNote,ccNote,ddNote,eeNote,ffNote,ggNote,ccsNote,ddsNote,ffsNote));
        notesNamesList = new ArrayList<>(Arrays.asList("c4","d4","e4","f4","g4","a4","b4","cs4","ds4","fs4","gs4","as4","c5","d5","e5","f5","g5","cs5","ds5","fs5"));

    }

    public ArrayList<Note> getNotesList() {
        return notesList;
    }

    public ArrayList<String> getNotesNamesList() {
        return notesNamesList;
    }

    public Note getC4Note() {
        return cNote;
    }

    public Note getD4Note() {
        return dNote;
    }

    public Note getE4Note() {
        return eNote;
    }

    public Note getF4Note() {
        return fNote;
    }

    public Note getG4Note() {
        return gNote;
    }

    public Note getA4Note() {
        return aNote;
    }

    public Note getB4Note() {
        return bNote;
    }

    public Note getCs4Note() {
        return csNote;
    }

    public Note getDs4Note() {
        return dsNote;
    }

    public Note getFs4Note() {
        return fsNote;
    }

    public Note getGs4Note() {
        return gsNote;
    }

    public Note getAs4Note() {
        return asNote;
    }

    public Note getC5Note() {
        return ccNote;
    }

    public Note getD5Note() {
        return ddNote;
    }

    public Note getE5Note() {
        return eeNote;
    }

    public Note getF5Note() {
        return ffNote;
    }

    public Note getG5Note() {
        return ggNote;
    }

    public Note getCs5Note() {
        return ccsNote;
    }

    public Note getDs5Note() {
        return ddsNote;
    }

    public Note getFs5Note() {
        return ffsNote;
    }

    public void play(String note_name)
    {
        int index = notesNamesList.indexOf(note_name);
        Note note = notesList.get(index);
        note.play();
    }

}
