package com.example.itamusic;

import java.io.Serializable;

public class Stats implements Serializable {

    private int intervalListeningQuestions;
    private int intervalListeningCorrect;
    private int noteListeningQuestions;
    private int noteListeningCorrect;
    private int chordProgressionQuestions;
    private int chordProgressionCorrect;
    private int noteReadingQuestions;
    private int noteReadingCorrect;

    // Constructor
    public Stats() {
        this.intervalListeningQuestions = 0;
        this.intervalListeningCorrect = 0;
        this.noteListeningQuestions = 0;
        this.noteListeningCorrect = 0;
        this.chordProgressionQuestions = 0;
        this.chordProgressionCorrect = 0;
        this.noteReadingQuestions = 0;
        this.noteReadingCorrect = 0;
    }

    // Increment methods
    public void incrementIntervalListeningQuestions(boolean correct) {
        intervalListeningQuestions++;
        if (correct) {
            intervalListeningCorrect++;
        }
    }

    public void incrementNoteListeningQuestions(boolean correct) {
        noteListeningQuestions++;
        if (correct) {
            noteListeningCorrect++;
        }
    }

    public void incrementChordProgressionQuestions(boolean correct) {
        chordProgressionQuestions++;
        if (correct) {
            chordProgressionCorrect++;
        }
    }

    public void incrementNoteReadingQuestions(boolean correct) {
        noteReadingQuestions++;
        if (correct) {
            noteReadingCorrect++;
        }
    }

    // Getters
    public int getIntervalListeningQuestions() {
        return intervalListeningQuestions;
    }

    public int getIntervalListeningCorrect() {
        return intervalListeningCorrect;
    }

    public int getNoteListeningQuestions() {
        return noteListeningQuestions;
    }

    public int getNoteListeningCorrect() {
        return noteListeningCorrect;
    }

    public int getChordProgressionQuestions() {
        return chordProgressionQuestions;
    }

    public int getChordProgressionCorrect() {
        return chordProgressionCorrect;
    }

    public int getNoteReadingQuestions() {
        return noteReadingQuestions;
    }

    public int getNoteReadingCorrect() {
        return noteReadingCorrect;
    }

    // Calculate success rates
    public double getIntervalListeningSuccessRate() {
        return calculateSuccessRate(intervalListeningCorrect, intervalListeningQuestions);
    }

    public double getNoteListeningSuccessRate() {
        return calculateSuccessRate(noteListeningCorrect, noteListeningQuestions);
    }

    public double getChordProgressionSuccessRate() {
        return calculateSuccessRate(chordProgressionCorrect, chordProgressionQuestions);
    }

    public double getNoteReadingSuccessRate() {
        return calculateSuccessRate(noteReadingCorrect, noteReadingQuestions);
    }

    // Helper method to calculate success rate
    private double calculateSuccessRate(int correct, int total) {
        if (total == 0) {
            return 0.0;
        }
        return (correct / (double) total) * 100.0;
    }
}
