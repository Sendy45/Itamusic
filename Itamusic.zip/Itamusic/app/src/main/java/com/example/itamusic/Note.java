package com.example.itamusic;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

public class Note {
    private String name;
    private int address;
    private float left_vol;
    private float right_vol;
    private int priority = 1;
    private int loop = 0;
    private float rate;
    private SoundPool mSoundPool = new SoundPool(20, AudioManager.STREAM_MUSIC,0);;
    private Context context;
    private int sound;
    private int half_tones;

    public Note(String name, int address, Context context, int half_tones) {
        this.name = name;
        this.address = address;
        this.context = context;
        this.half_tones = half_tones;
        left_vol = 1f;
        right_vol = 1f;
        rate = 1f;
        sound = mSoundPool.load(context,address,1);
    }

    public Note(String name, int address, float left_vol, float right_vol, float rate, Context context, int half_tones) {
        this.name = name;
        this.address = address;
        this.left_vol = left_vol;
        this.right_vol = right_vol;
        this.rate = rate;
        this.context = context;
        this.half_tones = half_tones;
        sound = mSoundPool.load(context,address,1);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    public float getLeft_vol() {
        return left_vol;
    }

    public void setLeft_vol(float left_vol) {
        this.left_vol = left_vol;
    }

    public float getRight_vol() {
        return right_vol;
    }

    public void setRight_vol(float right_vol) {
        this.right_vol = right_vol;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getLoop() {
        return loop;
    }

    public void setLoop(int loop) {
        this.loop = loop;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public int getSound() {
        return sound;
    }

    public void setSound(int sound) {
        this.sound = sound;
    }

    public int getHalf_tones() {
        return half_tones;
    }

    public void setHalf_tones(int half_tones) {
        this.half_tones = half_tones;
    }

    public void play()
    {
        mSoundPool.play(sound,left_vol,right_vol,priority,loop,rate);
    }


}
