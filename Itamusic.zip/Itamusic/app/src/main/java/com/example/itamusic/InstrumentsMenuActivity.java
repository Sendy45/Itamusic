package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class InstrumentsMenuActivity extends AppCompatActivity {

    ImageButton btnPianoActivity, btnGuitarActivity, btnDrumsActivity;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instruments_menu);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("InstrumentsMenuActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("InstrumentsMenuActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        btnPianoActivity = findViewById(R.id.btnPianoActivity);

        btnPianoActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent movePiano = new Intent(InstrumentsMenuActivity.this, PianoActivity.class);
                movePiano.putExtra("user", user);
                startActivity(movePiano);
            }
        });
    }
}