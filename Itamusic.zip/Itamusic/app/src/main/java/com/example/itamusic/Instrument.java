package com.example.itamusic;

import java.util.ArrayList;

public abstract class Instrument {
    protected String name;
    protected ArrayList<Note> notes_list;
    protected ArrayList<String> notes_names_list;

    public Instrument() {
        this.name = "";
        this.notes_list = new ArrayList<>();
        this.notes_names_list = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Note> getNotes_list() {
        return notes_list;
    }

    public void setNotes_list(ArrayList<Note> notes_list) {
        this.notes_list = notes_list;
    }

    public ArrayList<String> getNotes_names_list() {
        return notes_names_list;
    }

    public void setNotes_names_list(ArrayList<String> notes_names_list) {
        this.notes_names_list = notes_names_list;
    }

    public void play(String note_name) {}
}
