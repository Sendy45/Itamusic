package com.example.itamusic;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PianoActivity extends AppCompatActivity {

    Button c4,d4,e4,f4,g4,a4,b4,cs4,ds4,fs4,gs4,as4,c5,d5,e5,f5,g5,cs5,ds5,fs5;
    private Piano piano;
    private SoundPool mSoundPool;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano);

        // Get the User object from the Intent
        user = (User) getIntent().getSerializableExtra("user");

        // Check if the User object is null
        if (user != null) {
            // Use the user object as needed
            Log.d("PianoActivity", "User received: " + user.getName());
        } else {
            // Handle the case where user is null
            Log.e("PianoActivity", "User is null");
            Toast.makeText(this, "User data is missing", Toast.LENGTH_SHORT).show();
        }

        c4 = findViewById(R.id.c4);
        d4 = findViewById(R.id.d4);
        e4 = findViewById(R.id.e4);
        f4 = findViewById(R.id.f4);
        g4 = findViewById(R.id.g4);
        a4 = findViewById(R.id.a4);
        b4 = findViewById(R.id.b4);
        cs4 = findViewById(R.id.cs4);
        ds4 = findViewById(R.id.ds4);
        fs4 = findViewById(R.id.fs4);
        gs4 = findViewById(R.id.gs4);
        as4 = findViewById(R.id.as4);
        c5 = findViewById(R.id.c5);
        d5 = findViewById(R.id.d5);
        e5 = findViewById(R.id.e5);
        f5 = findViewById(R.id.f5);
        g5 = findViewById(R.id.g5);
        cs5 = findViewById(R.id.cs5);
        ds5 = findViewById(R.id.ds5);
        fs5 = findViewById(R.id.fs5);
        piano = new Piano(getApplicationContext());

        mSoundPool = new SoundPool(20,AudioManager.STREAM_MUSIC,0);

        c4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("c4");
                        break;
                }
                return false;
            }
        });
        d4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("d4");
                        break;
                }
                return false;
            }
        });
        e4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("e4");
                        break;
                }
                return false;
            }
        });
        f4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("f4");
                        break;
                }
                return false;
            }
        });
        g4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("g4");
                        break;
                }
                return false;
            }
        });
        a4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("a4");
                        break;
                }
                return false;
            }
        });
        b4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("b4");
                        break;
                }
                return false;
            }
        });
        cs4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("cs4");
                        break;
                }
                return false;
            }
        });
        ds4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("ds4");
                        break;
                }
                return false;
            }
        });
        fs4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("fs4");
                        break;
                }
                return false;
            }
        });
        gs4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("gs4");
                        break;
                }
                return false;
            }
        });
        as4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("as4");
                        break;
                }
                return false;
            }
        });
        c5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("c5");
                        break;
                }
                return false;
            }
        });
        d5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("d5");
                        break;
                }
                return false;
            }
        });
        e5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("e5");
                        break;
                }
                return false;
            }
        });
        f5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("f5");
                        break;
                }
                return false;
            }
        });
        g5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("g5");
                        break;
                }
                return false;
            }
        });
        cs5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("cs5");
                        break;
                }
                return false;
            }
        });
        ds5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("ds5");
                        break;
                }
                return false;
            }
        });
        fs5.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // PRESSED
                        piano.play("fs5");
                        break;
                }
                return false;
            }
        });
    }
}