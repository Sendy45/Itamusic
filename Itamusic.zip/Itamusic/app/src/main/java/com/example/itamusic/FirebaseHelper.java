package com.example.itamusic;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FirebaseHelper {

    private static final String TAG = "FirebaseHelper";
    private DatabaseReference database;

    public FirebaseHelper() {
        // Initialize the connection to the database
        database = FirebaseDatabase.getInstance().getReference();
    }

    public DatabaseReference getDatabase(){
        return database;
    }

    public void uploadUserData(User user) {
        // Upload user data under the "users" path
        database.child("users").child(user.getId()).setValue(user)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "User data uploaded successfully"))
                .addOnFailureListener(e -> Log.w(TAG, "User data upload failed", e));
    }

    public void uploadUserStats(String userId, Stats stats) {
        // Upload stats data under the specific user ID
        database.child("users").child(userId).child("stats").setValue(stats)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Stats uploaded successfully"))
                .addOnFailureListener(e -> Log.w(TAG, "Stats upload failed", e));
    }

    public static User getUser(String userId, Context context) {
        // Declare the user object outside the asynchronous method to be used inside it
        final User[] fetchedUser = new User[1];

        // Fetch user data by ID
        FirebaseDatabase.getInstance().getReference()
                .child("users")
                .child(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            fetchedUser[0] = snapshot.getValue(User.class); // Fetch user and store it
                        }
                        else {
                            Toast.makeText(context, "User Not Found", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Log error if the query fails
                        Log.e("FirebaseHelper", "Failed to fetch user", error.toException());
                    }
                });

        // Return the fetched user (this will be null initially)
        return fetchedUser[0];
    }

    public static ArrayList<User> getAllUsers(Context context) {

        FirebaseHelper firebaseHelper = new FirebaseHelper();
        DatabaseReference database = firebaseHelper.getDatabase();
        ArrayList<User> allUsers = new ArrayList<>();
        // Fetch all users data
        database.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Loop through all children (users)
                    for (DataSnapshot dat : snapshot.getChildren()) {
                        User user = dat.getValue(User.class);
                        allUsers.add(user);
                    }
                }
                else {
                    Toast.makeText(context, "No users found", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseHelper", "Failed to fetch users", error.toException());
            }

        });
        return allUsers;
    }
}


